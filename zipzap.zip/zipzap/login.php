<?php
        // mengaktifkan session pada php
        session_start();
        // menghubungkan php dengan koneksi database
        include 'config.php';
        // menangkap data yang dikirim dari form login
        $username = mysqli_real_escape_string($koneksi, $_POST['username']); // Ambil value username yang dikirim dari form
		$password = mysqli_real_escape_string($koneksi, $_POST['password']); // Ambil value password yang dikirim dari form

        // menyeleksi data user dengan username dan password yang sesuai
        // $conn sesuaikan dengan nama variabel yang kalian buat saat membuat koneksi ke database
        $login = mysqli_query($koneksi, "SELECT * FROM user WHERE username='".$username."' AND password='".$password."'");
        // menghitung jumlah data yang ditemukan
        $cek = mysqli_num_rows($login);
        // cek apakah username dan password di temukan pada database
if( ! empty($cek)){
    $data = mysqli_fetch_assoc($login);
    // cek jika user login sebagai admin
    if($data['jenis_user']=="admin"){
        // buat session login dan username
        $_SESSION['username'] = $data['username'];
        $_SESSION['nama_lengkap']  = $data['nama_lengkap'];
        $_SESSION['jenis_user']    = "admin";
		$_SESSION['email'] = $data['email']; // Set session untuk nama (simpan nama di session)
	
		setcookie("message","delete",time()-1); // Kita delete cookie message
	
        // alihkan ke halaman dashboard admin
        header("location:index_admin.php");
    // cek jika user login sebagai pegawai
    }else if($data['jenis_user']=="user"){
        // buat session login dan username
        $_SESSION['username'] = $data['username'];
        $_SESSION['nama_lengkap'] = $data['nama_lengkap'];
        $_SESSION['jenis_user'] = "user";
		$_SESSION['email'] = $data['email']; // Set session untuk nama (simpan nama di session)
	
		setcookie("message","delete",time()-1); // Kita delete cookie message
	
        // alihkan ke halaman dashboard pegawai
        header("location:index2.php");
    // cek jika user login sebagai pengurus
    }else{
        // alihkan ke halaman login kembali jika password dan username tidak sesuai
        header("location:Login1.php?pesan=gagal");
    }  
}else{
        header("location:indexx.php?pesan=gagal");
}
 
?>