 <?php
include 'config.php';
//Start Aksi user
$g=$_GET['sender'];
if($g=='sepatu')
{
    $sql="INSERT INTO sepatu (jenis_sepatu, foto)
        VALUES
        ('$_POST[jenis_sepatu]',
         '$_POST[foto]')";
        if (mysqli_query($koneksi, $sql)){
        echo '<script LANGUAGE="JavaScript">
            alert("Jenis Sepatu dengan Nama :('.$_POST[jenis_sepatu].') Tersimpan")
            window.location.href="index_admin.php?page=sepatu";
            </script>'; 
        }
    else{
        echo "Error : ".$sql.". ".mysqli_error($koneksi);
    }
     //header('location:http://localhost/');
}

else 
    if($g=='edit')
    {   
        mysqli_query($koneksi,
            "UPDATE sepatu 
            SET jenis_sepatu    ='$_POST[jenis_sepatu]',
                foto            ='$_POST[foto]'
            WHERE id_sepatu = '$_POST[id_sepatu]'");
            
         echo '<script LANGUAGE="JavaScript">
            alert("Jenis Sepatu dengan nama :('.$_POST[jenis_sepatu].') Di Update")
            window.location.href="index_admin.php?page=sepatu";
            </script>';
    } 
else 
    if($g=='hapus')
    {
         mysqli_query($koneksi,"DELETE FROM sepatu where id_sepatu='$_GET[id]'");
         echo '<script LANGUAGE="JavaScript">
            alert("Jenis Sepatu dengan nama :('.$_GET[jenis_sepatu].') Di Terhapus")
            window.location.href="index_admin.php?page=sepatu";
            </script>';
    }
?>
