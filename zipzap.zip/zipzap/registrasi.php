﻿	<?php

require_once("config.php");

if(isset($_POST['register'])){

    // filter data yang diinputkan
    $nama_lengkap = filter_input(INPUT_POST, 'nama_lengkap', FILTER_SANITIZE_STRING);
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
	$jenis_kelamin = filter_input(INPUT_POST, 'jenis_kelamin', FILTER_SANITIZE_STRING);
	$no_tlp = filter_input(INPUT_POST, 'no_tlp', FILTER_SANITIZE_STRING);
    // enkripsi password
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);


    // menyiapkan query
    $sql = "INSERT INTO user (nama_lengkap, username, jenis_kelamin, no_tlp, email, password) 
            VALUES (:nama_lengkap, :username, :jenis_kelamin, :no_tlp, :email, :password)";
    $stmt = $koneksi->prepare($sql);

    // bind parameter ke query
    $params = array(
        ":nama_lengkap" => $nama_lengkap,
        ":username" => $username,
		":no_tlp" => $no_tlp,
		":jenis_kelamin" => $jenis_kelamin,
        ":password" => $password,
        ":email" => $email
    );

    // eksekusi query untuk menyimpan ke database
    $saved = $stmt->execute($params);

    // jika query simpan berhasil, maka user sudah terdaftar
    // maka alihkan ke halaman login
    if($saved) header("Location: login1.php");
}

?>


<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="utf-8" />
    <title>ZipZap - Register</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta content="" name="description" />
    <meta content="" name="author" />
    <!-- BEGIN CORE CSS FRAMEWORK -->
    <link rel="stylesheet" type="text/css" href="assets/plugins/owl-carousel/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="assets/plugins/owl-carousel/owl.theme.css" />
    <link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css"
        media="screen" />
    <link href="assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet"
        type="text/css" />
    <link href="assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet"
        type="text/css" />
    <!-- END CORE CSS FRAMEWORK -->
    <!-- BEGIN CSS TEMPLATE -->
    <link href="assets/css/style.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/animate.min.css" rel="stylesheet" type="text/css" />
    <!-- END CSS TEMPLATE -->
    <script type="text/javascript" src="assets/plugins/jquery-1.8.3.min.js"></script>
</head>
<!-- END HEAD -->
<body >

        <div class="section blue text-center m-t-10 p-t-5 p-b-5" id="banner-footer">
            <strong><h2 class="normal m-b-10" >ZipZap Shoe Laundry</h2>
            <p></p></strong>
			
		
        
        <div class="row">
        <div class="col-xs-80 col-xs-offset-1 col-sm-10 col-sm-offset-2 col-md-4 col-md-offset-4">
            <div class="login-panel panel panel-default">
                <div class="panel-heading"><strong>Sign Up</strong></div>
                <div class="panel-body">
                     <form action="" method="POST">
					 
			<div class="form-group">
                <label for="nama_lengkap"> Nama Lengkap</label>
                <input class="form-control" type="text" name="nama_lengkap" placeholder="Nama Lengkap" />
            </div>
			
			<div class="form-group">
                <label for="username">Username</label>
                <input class="form-control" type="text" name="username" placeholder="Username" />
            </div>
			
			<div class="form-group">
				<label>Jenis Kelamin</label><br>
				<input class="auto-save" type="radio" name="jenis_kelamin" id="jenkel1" value="Laki-laki"> Laki-laki
				<input class="auto-save" type="radio" name="jenis_kelamin" id="jenkel2" value="Perempuan"> Perempuan
			</div>
			s
			<div class="form-group">
                <label for="no_tlp"> No Hp</label>
                <input class="form-control" type="text" name="no_tlp" placeholder="No Hp" />
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input class="form-control" type="email" name="email" placeholder="Email" />
            </div>


            <div class="form-group">
                <label for="password">Password</label>
                <input class="form-control" type="password" name="password" placeholder="Password" />
            </div>


            <input type="submit" class="btn btn-success btn-block" name="register" value="Daftar" />

        </form>
					</div>
                        
    <!-- BEGIN CORE JS FRAMEWORK -->
    <script type="text/javascript" src="assets/plugins/jquery-1.8.3.min.js"></script>
    <script src="assets/plugins/boostrapv3/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- END CORE JS FRAMEWORK -->
    <!-- BEGIN JS PLUGIN -->
    <script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
    <script src="assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="assets/plugins/jquery-nicescroll/jquery.nicescroll.min.js"></script>
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script src="assets/plugins/jquery-gmap/gmaps.js" type="text/javascript"></script>
    <!-- END JS PLUGIN -->
    <script src="assets/js/google_maps.js" type="text/javascript"></script>
    <script type="text/javascript" src="assets/js/core.js"></script>
  
</body>
</html>