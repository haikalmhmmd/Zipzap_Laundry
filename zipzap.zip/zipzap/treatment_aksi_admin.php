<?php
include 'config.php';

$g=$_GET['sender'];
if($g=='treatment')
{
    $sql="INSERT INTO metode_cuci (id_sepatu, jenis_treatment, harga, deskripsi, foto_treatment)
        VALUES
        ('$_POST[id_sepatu]',
        '$_POST[jenis_treatment]',
        '$_POST[harga]',
        '$_POST[deskripsi]',
        '$_POST[foto_treatment]'
        )";   
        if (mysqli_query($koneksi, $sql)){ 
        echo '<script LANGUAGE="JavaScript">
            alert("Jenis Treatment baru dengan nama :('.$_POST[jenis_treatment].') Tersimpan")
            window.location.href="index_admin.php?page=treatment";
            </script>'; 
    }
    else{
        echo "Error : ".$sql.". ".mysqli_error($koneksi);
    }
     //header('location:http://localhost/');
}

else 
    if($g=='edit')
    {
        mysqli_query($koneksi,
            "UPDATE metode_cuci
            SET id_sepatu           ='$_POST[id_sepatu]',
                status_treatment     ='$_POST[status_treatment]', 
            WHERE id_metode_cuci='$_POST[id_metode_cuci]'");
         echo '<script LANGUAGE="JavaScript">
            alert("Jenis Treatment dengan nama :('.$_POST[jenis_treatment].') Di Update")
            window.location.href="index_admin.php?page=treatment";
            </script>';
        }
else 
    if($g=='hapus')
    {
        mysqli_query($koneksi,"DELETE FROM metode_cuci where id_metode_cuci='$_GET[id]'");
         echo '<script LANGUAGE="JavaScript">
            alert("Jenis Treatment dengan nama :('.$_GET[jenis_treatment].') Di Terhapus")
            window.location.href="index_admin.php?page=treatment";
            </script>';
    }
?>
