﻿<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="utf-8" />
    <title>ZipZap Shoe Laundry</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta content="" name="description" />
    <meta content="" name="author" />
    <link rel="stylesheet" type="text/css" href="assets/plugins/owl-carousel/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="assets/plugins/owl-carousel/owl.theme.css" />
    <link rel="stylesheet" type="text/css" href="assets/plugins/headereffects/css/component.css">
    <link rel="stylesheet" type="text/css" href="assets/plugins/headereffects/css/normalize.css" />
    <link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css"
        media="screen" />
    <!-- BEGIN CORE CSS FRAMEWORK -->
    <link href="assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet"
        type="text/css" />
    <link href="assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet"
        type="text/css" />
    <!-- END CORE CSS FRAMEWORK -->
    <!-- BEGIN CSS TEMPLATE -->
    <link href="assets/css/style.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/magic_space.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/animate.min.css" rel="stylesheet" type="text/css" />
    <!-- END CSS TEMPLATE -->
    <script type="text/javascript" src="assets/plugins/jquery-1.8.3.min.js"></script>
    <!-- SLIDER REVOLUTION 4.x SCRIPTS  -->
    <script type="text/javascript" src="assets/plugins/slider-plugin/js/slider1.min.js"></script>
    <script type="text/javascript" src="assets/plugins/slider-plugin/js/slider2.min.js"></script>
    <link rel="stylesheet" type="text/css" href="assets/plugins/slider-plugin/css/settings.css"
        media="screen" />
</head>
<!-- END HEAD -->
<body>
    <div class="main-wrapper">
        <header id="ha-header" class="ha-header ha-header-hide ">
            <div class="ha-header-perspective">
                <div class="ha-header-front navbar navbar-default">
                    <div class="compressed">
                        <div class="navbar-header">
                            <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle"
                                type="button">
                                <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span><span
                                    class="icon-bar"></span><span class="icon-bar"></span>
                            </button>
                            <a href="#" class="navbar-brand compressed">
                                <img src="assets/img/zipzap.jpg" alt="" data-src="assets/img/zipzap.jpg"
                                    data-src-retina="assets/img/zipzap2x.jpg" width="100" height="50" /></a>
                        </div>
                        <div class="navbar-collapse collapse">
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="index.html">Home</a></li>
                                <li><a href="Login1.php">Login</a></li>
                                <li><a href="daftar_akun.html">Daftar Akun</a></li>
                                <li><a href="order.html">Order</a></li>
                                <li><a href="contact.html">About Us</a></li>
                            </ul>
                        </div>
                        /.nav-collapse
                    </div>
                </div>
            </div>
        </header>
        <div class="section ha-waypoint" data-animate-down="ha-header-hide" data-animate-up="ha-header-hide">
            <div role="navigation" class="navbar navbar-transparent navbar-top">
                <div class="container">
                    <div class="compressed">
                        <div class="navbar-header">
                            <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle"
                                type="button">
                                <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span><span
                                    class="icon-bar"></span><span class="icon-bar"></span>
                            </button>
                            <a href="#" class="navbar-brand">
                                <img src="assets/img/zipzap.jpg" data-src="assets/img/zipzap.jpg" data-src-retina="assets/img/zipzap_2x.jpg"
                                    width="120" height="60" alt="" /></a>
                        </div>
                        <div class="navbar-collapse collapse">
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="index.html">Home</a></li>
                                <li><a href="Login1.php">Login</a></li>
                                <li><a href="daftar_akun.html">Daftar Akun</a></li>
                                <li><a href="order.html">Order</a></li>
                                <li><a href="contact.html">About Us</a></li>
                            </ul>
                        </div>
                        <!--/.nav-collapse -->
                    </div>
                </div>
            </div>
            <!--BEGIN SLIDER -->
            <div class="tp-banner-container">
                <div class="tp-banner" id="home">
                    <ul>
                        <!-- SLIDE  -->
                        <li data-transition="fade" data-slotamount="5" data-masterspeed="700">
                            <!-- MAIN IMAGE -->
                            <img src="assets/img/bg/gambar1.jpg" alt="slidebg1" data-bgfit="cover" data-bgposition="center center"
                                data-bgrepeat="no-repeat">
                            <!-- LAYERS -->
                            <div class="tp-caption mediumlarge_light_white_center sft tp-resizeme slider" data-x="center"
                                data-hoffset="0" data-y="80" data-speed="500" data-start="800" data-easing="Power4.easeOut"
                                data-endspeed="300" data-endeasing="Power1.easeIn" data-captionhidden="off" style="z-index: 6">
                                <h2 class="text-white custom-font title">
                                    Yuk Cuci Sepatumu<br>
                                    Silahkan Login
                                    <br/>
                                    Dulu Dibawah Ini!</h2>
                            </div>
                            <div class="tp-caption sfb slider tp-resizeme slider" data-x="center" data-hoffset="0"
                                data-y="320" data-speed="800" data-start="1000" data-easing="Power4.easeOut"
                                data-endspeed="300" data-endeasing="Power1.easeIn" data-captionhidden="off" style="z-index: 6">
                                <a href= "Login1.php" class="btn btn-info btn-lg  btn-large m-r-10">Login Sekarang!</a>
                            </div>
                        </li>
                        <li data-transition="fade" data-slotamount="5" data-masterspeed="700">
                            <!-- MAIN IMAGE -->
                            <img src="assets/img/bg/gambar2.jpg" alt="slidebg2" data-bgfit="cover" data-bgposition="center center"
                                data-bgrepeat="no-repeat">
                            <!-- LAYERS -->
                            <div class="tp-caption mediumlarge_light_white_center sft tp-resizeme slider" data-x="center"
                                data-hoffset="0" data-y="120" data-speed="500" data-start="800" data-easing="Power4.easeOut"
                                data-endspeed="300" data-endeasing="Power1.easeIn" data-captionhidden="off" style="z-index: 6">
                                <h2 class="text-white custom-font title ">
                                    Ingin Info Lebih Lanjut<br>
                                    Klik Dibawah Ini!</h2>
                            </div>
                            <div class="tp-caption sfb slider tp-resizeme slider" data-x="center" data-hoffset="0"
                                data-y="300" data-speed="800" data-start="1000" data-easing="Power4.easeOut"
                                data-endspeed="300" data-endeasing="Power1.easeIn" data-captionhidden="off" style="z-index: 6">
                                <a href= "contact.html" class="btn btn-info btn-lg  btn-large m-r-10">Info Lengkap Kami</a>
                            </div>
                            <!--<div class="tp-caption fade slider tp-resizeme slider" data-x="center" data-hoffset="0"
                                data-y="360" data-speed="500" data-start="800" data-easing="Power4.easeOut" data-endspeed="300"
                                data-endeasing="Power1.easeIn" data-captionhidden="off" style="z-index: 6">
                                <a href="#" class="text-white m-r-10">or view our pricing</a>
                            </div>-->
                        </li>
                        <!-- SLIDE  -->
                        <li data-transition="fade" data-slotamount="5" data-masterspeed="700">
                            <!-- MAIN IMAGE -->
                            <img src="assets/img/bg/gambar3.png" alt="slidebg2" data-bgfit="cover" data-bgposition="center center"
                                data-bgrepeat="no-repeat">
                            <!-- LAYERS -->
                            <div class="tp-caption mediumlarge_light_white_center sft tp-resizeme slider" data-x="center"
                                data-hoffset="0" data-y="120" data-speed="500" data-start="800" data-easing="Power4.easeOut"
                                data-endspeed="300" data-endeasing="Power1.easeIn" data-captionhidden="off" style="z-index: 6">
                                <h2 class="text-white custom-font title ">
                                    Macam-Macam Treatment<br>
                                    Yang Kami Pakai</h2>
                            </div>
                            <div class="tp-caption sfb slider tp-resizeme slider" data-x="center" data-hoffset="0"
                                data-y="300" data-speed="800" data-start="1000" data-easing="Power4.easeOut"
                                data-endspeed="300" data-endeasing="Power1.easeIn" data-captionhidden="off" style="z-index: 6">
                                <a href="#" class="btn btn-info btn-lg  btn-large m-r-10">Klik Disini!</a>
                            </div>
                        </li>
                    </ul>
                    <div class="tp-bannertimer">
                    </div>
                </div>
            </div>
            <!--END SLIDER-->
        </div>
        <div class="section ">
            <div class="container">
                <div class="p-t-40 p-b-40  text-center">
                    <h2 class="text-center">
                        Kenapa Harus Cuci Di ZipZap?</h2>                    
                </div>
            </div>
        </div>
        <div class="section white ha-waypoint" data-animate-down="ha-header-color" data-animate-up="ha-header-hide">
            <div class="container" >
                <div class="p-t-40 p-b-40  text-center">
                    <div class="row">
                        <div class="col-md-100 feature-list ">
                            <div class="col-md-4" data-ride="animated" data-animation="fadeIn" data-delay="300">
                                <img src="assets/img/term.png" width="60" height="60" alt="">
                                <h4 class="title">
                                    MINIMUM 4 SEPATU YANG HARUS DICUCI</h4>
                                <p><font face="garamond" size="3">
                                    Anda dapat mencuci sepatu kesayangan anda diini, dengan syarat mencuci dengan jumlah minimal 4 sepatu. Dan bisa langsung di antar-jemput dengan GRATIS (berlaku hanya di wilayah JABODETABEK).</font>
                                </p>
                            </div>                            
                            <div class="col-md-4" data-ride="animated" data-animation="fadeIn" data-delay="300">
                                <img src="assets/img/free.png" width="60" height="60" alt="">
                                <h4 class="title">
                                    FREE DELIVERY</h4>
                                <p><font face="garamond" size="3">
                                    Anda akan mendapatkan free dalam antar jemput sepatu hanya berlaku di wilayah JABODETABEK saja.</font>
                                </p>
                            </div>
                            <div class="col-md-4" data-ride="animated" data-animation="fadeIn" data-delay="300">
                                <img src="assets/img/time.png" width="60" height="60" alt="">
                                <h4 class="title">
                                    HEMAT WAKTU</h4>
                                <p><font face="garamond" size="3">
                                    Anda tidak perlu menyerahkan sepatu kotor anda dengan datang ke store kami. Cukup pesan antar-jemput online ini kapan pun dan dimana pun.</font>
                                </p>
                            </div>                            
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-md-24 feature-list">
                            <div class="col-md-4" data-ride="animated" data-animation="fadeIn" data-delay="600">
                                <img src="assets/img/shoes.png" width="60" height="60" alt="">
                                <h4 class="title">
                                    BERSIH DAN WANGI</h4>
                                <p><font face="garamond" size="3">
                                    Kami memberikan hasil yang maksimal dengan kebersihan dan dilengkapi dengan parfum pada sepatu kesayangan anda dengan pilihan layanan yang bisa anda pilih sesuai keinginan. Dan buktikan hasilnya.</font>
                                </p>
                            </div>
                            <div class="col-md-4" data-ride="animated" data-animation="fadeIn" data-delay="1200">
                                <img src="assets/img/brush.png" width="60" height="60" alt="">
                                <h4 class="title">
                                    DICUCI DENGAN AHLINYA</h4>
                                <p><font face="garamond" size="3">
                                    Tim kami sangat berpengalaman dalam menangani segala jenis sepatu. Percayakanlah sepatu anda dengan tangan tim cuci sepatu handal kami.</font>
                                </p>
                            </div>
                            <div class="col-md-4" data-ride="animated" data-animation="fadeIn" data-delay="1500">
                                <img src="assets/img/target.png" width="60" height="60" alt="">
                                <h4 class="title">
                                    HARGA TERJANGKAU</h4>
                                <p><font face="garamond" size="3">
                                    Dengan kualitas tinggi, layanan kami memberikan tarif yang pas dengan kantong anda. Dan banyaknya harga spesial di ZipZap ini. Sepatu anda bersih, harga pas dikantong.</font>
                                </p>
                            </div>                            
                            <div class="clearfix">
                            </div>
                        </div>
                    </div>
                    <!--<div class="section relative">
                        <div class="row text-center">
                            <img src="assets/img/browser-shot.png" alt="" class="resize p-t-60 col-md-12 hidden-xs"
                                style="" data-ride="animated" data-animation="fadeInUp" data-delay="300">
                        </div>
                    </div>-->
                    <div class="clearfix">
                    </div>
                </div>
            </div>
        </div>        
        <div class="section grey">
            <div class="container">
                <div class="p-t-60 p-b-50">
                    <div id="testomonials" class="owl-carousel row">
                        <div class="item">
                            <div class="col-md-6  col-md-offset-3 text-center">
                                <img src="assets/img/testimoni/testimoni1.png" alt="testimonal">                                
                                <div class="testimonial-user">
                                    <span>triaand_</span>
                                </div>
                                <h4 class="normal text-center">
                                    Vans Old School - Premium Treatment.<br> Terimakasih ya! Super bersih mendetail dan wanginya enaaakk~<br>Yuk yang sepatunya masih kotor tapi belum dibersihkan, bisa langsung order disini dan dapatkan harga spesial dan buktikan hasilnya. #ZipZapCleaning
                                </h4>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-md-6  col-md-offset-3 text-center">
                                <img src="assets/img/testimoni/testimoni2.png" alt="testimonal">                                
                                <div class="testimonial-user">
                                    <span>Kevin Tria</span>
                                </div>
                                <h4 class="normal text-center">
                                    Vans Splitfire Slip On - Premium Treatment<br> Langsung seperti baru sepatu gue abis cuci di ZipZap. Terimakasih banyak! Langsung cuci sepatu kotor lo disini. #ZipZapCleaning
                                </h4>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-md-6  col-md-offset-3 text-center">
                                <img src="assets/img/testimoni/testimoni3.png" alt="testimonal">                                
                                <div class="testimonial-user">
                                    <span>Yuayprem</span>
                                </div>
                                <h4 class="normal text-center">
                                    Adidas Superstar - White Treatment<br>Sepatu putih pun langsung sebersih ini. Engga ngerti lagi sebagus ini nyucinya. Engga takut lagi buat keluar rumah dengan sepatu putih karena sudah bersih dan wangi. Terimakasih ZipZap! #ZipZapCleaning
                                </h4>
                            </div>
                        </div>                        
                    </div>
                </div>
            </div>
        </div>
        <div class="section black contact-details">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 text-center">
                        <div class="services-box-3">
                            <img src="assets/img/phone.png" width="50" height="50" alt="">
                            <div class="content">
                                <p>
                                    Phone</p>
                                <h3><a href="whatsapp:contact=81314584964@s.whatsapp.com&message="Hallo saya ingin mencuci sepatu, bisa dibantu jelaskan detailnya? Terimakasih"" style="color: #FFFFFF">+62 813-1458-4964</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 text-center">
                        <div class="services-box-3">
                            <img src="assets/img/email.png" width="50" height="50" alt="">
                            <div class="content">
                                <p>
                                    E-mail</p>
                                <h3><a href="mailto:id.zipzap@gmail.com" style="color: #FFFFFF">id.zipzap@gmail.com</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 text-center">
                        <div class="services-box-3">
                            <img src="assets/img/address.png" width="50" height="50" alt="">
                            <div class="content">
                                <p>
                                    Address</p>
                                <h3>
                                    Jl. H. Nasiin, RT.002 RW.004, Cilandak Barat, Jakarta Selatan, Indonesia</h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 text-center">
                        <div class="services-box-3">
                            <img src="assets/img/instagram.png" width="50" height="50" alt="">
                            <div class="content">
                                <p>
                                    Instagram</p>                                
                                <h3><a href="https://www.instagram.com/id.zipzap" style="color: #FFFFFF">id.zipzap</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 text-center">
                        <div class="services-box-3">
                            <img src="assets/img/calendar.png" width="55" height="55" alt="">
                            <div class="content">
                                <p>
                                    Jam Operasional</p>                                
                                <h3>Senin - Jum'at*<br>Pukul 10.00 - 14.00 WIB<br>*Hari Libur Tutup</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="section white footer">
            <div class="container">
                <div class="p-t-30 p-b-50">
                    <div class="row">
                        <div class="col-md-2 col-lg-2 col-sm-2 col-xs-12 xs-m-b-20">                            
                            <br />
                            © ZipZap Shoe Laundry.
                            <br />
                            All Rights Reserved.
                        </div>
                        <div class="col-md-4 col-lg-3 col-sm-4  col-xs-12 xs-m-b-20">
                            <address class="xs-no-padding  col-md-6 col-lg-6 col-sm-6  col-xs-12">
                                Jl. H. Nasiin,<br>
                                Cilandak Barat,<br>
                                Jakarta Selatan, Indonesia.
                            </address>
                            <div class="xs-no-padding col-md-6 col-lg-6 col-sm-6">
                                <div>
                                    +62 813-1458-4964</div>
                                <a href="javascript:">id.zipzap@gmail.com</a>
                            </div>
                            <div class="clearfix">
                            </div>
                        </div>
                        <!--<div class="col-md-2 col-lg-2 col-sm-2  col-xs-12 xs-m-b-20">
                            <div class="bold">
                                We Are Hiring</div>
                            Send you resume at <a href="javascript:">careers@thempleite.com</a>
                        </div>-->
                        <div class="col-md-2 col-lg-2 col-sm-2  col-xs-12 ">
                            <div class="bold">
                                FOLLOW US</div>
                            <br />
                            <a href="https://www.instagram.com/id.zipzap"><i class="fa fa-instagram fa-2x"></i></a><!--&nbsp; <a href="javascript:">
                                <i class="fa fa-twitter fa-2x"></i></a>&nbsp; <a href="javascript:"><i class="fa fa-youtube-play  fa-2x">
                                </i></a>&nbsp; <a href="javascript:"><i class="fa fa-github fa-2x"></i></a>&nbsp;
                            <a href="javascript:"><i class="fa fa-dribbble fa-2x"></i></a>&nbsp; <a href="javascript:">
                                <i class="fa fa-pinterest fa-2x"></i></a>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/plugins/boostrapv3/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
    <script src="assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
    <script src="assets/plugins/owl-carousel/owl.carousel.min.js" type="text/javascript"></script>
    <script src="assets/plugins/waypoints.min.js"></script>
    <script type="text/javascript" src="assets/plugins/parrallax/js/jquery.parallax-1.1.3.js"></script>
    <script type="text/javascript" src="assets/plugins/jquery-nicescroll/jquery.nicescroll.min.js"></script>
    <script type="text/javascript" src="assets/plugins/jquery-appear/jquery.appear.js"></script>
    <script src="assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
    <script type="text/javascript" src="assets/js/core.js"></script>
</body>
</html>
