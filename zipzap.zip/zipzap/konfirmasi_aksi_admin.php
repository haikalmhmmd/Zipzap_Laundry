<?php
include 'config.php';

$g=$_GET['sender'];
if($g=='konfirmasi')
{
    $sql="INSERT INTO konfirmasi (nama, id_pesanan,norek, foto)
        VALUES
        ($nama              ='$_POST[nama]',
         $id_pesanan        ='$_POST[id_pesanan]',
         $id_pesanan        ='$_POST[norek]',
         $foto              ='$_POST[foto]')"; 
        if (mysqli_query($koneksi, $sql)){ 
        echo '<script LANGUAGE="JavaScript">
            alert("Konfirmasi baru dengan nama :('.$_POST[nama].') Tersimpan")
            window.location.href="index_admin.php?page=konfirmasi";
            </script>'; 
    }
    else{
        echo "Error : ".$sql.". ".mysqli_error($koneksi);
    }
     //header('location:http://localhost/');
}
?>
