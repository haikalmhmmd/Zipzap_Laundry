<?php
	echo "cleared";
?>