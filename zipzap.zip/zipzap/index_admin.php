<?php

    session_start();

    if(! isset($_SESSION['username']))
    {
        header("location: indexx.php");
    }
error_reporting(0);
include 'config.php';
$get=$_GET['page'];

if (empty($get)=='beranda')
{
   include ('master_admin/beranda.php');	
}

elseif ($get=='order')
{
  include ('master_admin/order.php');
}

elseif ($get=='treatment')
{
	include('master_admin/jenis_treatment.php');
}

elseif ($get=='sepatu')
{
	include('master_admin/jenis_sepatu.php');
}

elseif ($get=='user')
{
  include ('master_admin/user.php');
}


elseif ($get=='logout')
{
  include ('logout.php');
}
?>