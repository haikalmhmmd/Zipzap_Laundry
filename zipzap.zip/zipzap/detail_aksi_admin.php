<?php
include 'config.php';

$g=$_GET['sender'];
if($g=='detail_pesanan')
{
    $sql="INSERT INTO detail_pesanan (id_pesanan, jenis_treatment, deskripsi, foto_detail)
        VALUES
        ($id_pesanan              ='$_POST[id_pesanan]',
         $jenis_treatment         ='$_POST[jenis_treatment]',
         $deskripsi               ='$_POST[deskripsi_detail]',
         $foto_detail             ='$_POST[foto_detail]')"; 
        if (mysqli_query($koneksi, $sql)){ 
        echo '<script LANGUAGE="JavaScript">
            alert("Konfirmasi baru dengan nama :('.$_POST[jenis_treatment].') Tersimpan")
            window.location.href="index_admin.php?page=detail_pesanan";
            </script>'; 
    }
    else{
        echo "Error : ".$sql.". ".mysqli_error($koneksi);
    }
     //header('location:http://localhost/');
}
?>
