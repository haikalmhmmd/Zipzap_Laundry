<!DOCTYPE html>
<html>

<?php
    session_start();

    if(! isset($_SESSION['username']))
    {
        header("location: indexx.php");
    }

    //koneksi ke database
    include ('config.php');

    if(isset($_POST['submits']))
    {
        $_SESSION['jumlah'] = $_POST["jumlah"];

        header("location: order2.php");
    }
?>

<script type="text/javascript">
    // function numbers()
    // {
    //     $x = document.getElementById("formnumber").value;
        // <?php echo $x ?>
    // }
    // var rad = document.cardsepatu.product;
    // var prev = null;
    // for (var i = 0; i < rad.length; i++) {
    //     rad[i].addEventListener('change', function() {
    //         (prev) ? console.log(prev.value): null;
    //         if (this !== prev) {
    //             prev = this;
    //             <?php echo $prev ?>
    //         }
    //         console.log(this.value)
    //     });
    // }


    // function showTreatment()
    // {
    //     var selectBox = document.getElementById('product')
    //     var userInput = selectBox.options[selectBox.selectedIndex].value;
    //     if (userInput == 'casual')
    //     {
    //         document.getElementById('casualtreatment').style.visibility='hidden';
    //     }
    //     else
    //     {
    //         document.getElementById('casualtreatment').style.visibility='hidden';
    //     }
    //     return false;
    // }

    // $selected_gender='';
    // function get_radio_button($select)
    // {
    //     $btns = array('Male','Female')
    //     $str='';
    //     while(list($k,$v)=each($btns))
    //     {
    //         if ($select==$v) 
    //         {
    //             $str .=$k. '&nbsp; <input type="radio" checked onchange="this.form.submit();"" name="gender[]" value="'.$v.'"/>';    
    //         }
    //         else
    //         {
    //             $str .=$k. '&nbsp; <input type="radio" onchange="this.form.submit();"" name="gender[]" value="'.$v.'"/>';
    //         }
            
    //     }
    //     return $str;
    // }
    // if (isset($_POST['gender'][0])) 
    // {
    //     $selected_gender = $_POST['gender'][0];
    //     echo $selected_gender;
    // }
</script>

<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="utf-8" />
    <title>ZipZap Shoe Laundry</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta content="" name="description" />
    <meta content="" name="author" />
    <!-- BEGIN CORE CSS FRAMEWORK -->
    <link rel="stylesheet" type="text/css" href="assets/plugins/owl-carousel/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="assets/plugins/owl-carousel/owl.theme.css" />
    <link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css"
        media="screen" />
    <link href="assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet"
        type="text/css" />
    <link href="assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet"
        type="text/css" />
    <!-- END CORE CSS FRAMEWORK -->
    <!-- BEGIN CSS TEMPLATE -->
    <link href="assets/css/style.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/animate.min.css" rel="stylesheet" type="text/css" />
    <!-- END CSS TEMPLATE -->
    <script type="text/javascript" src="assets/plugins/jquery-1.8.3.min.js"></script>

    <div class="main-wrapper">
        <div role="navigation" class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="compressed">
                    <div class="navbar-header">
                        <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle"
                            type="button">
                            <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span><span
                                class="icon-bar"></span><span class="icon-bar"></span>
                        </button>
                        <a href="#" class="navbar-brand compressed">
                            <img src="assets/img/zipzap.jpg" alt="" data-src="assets/img/zipzap.jpg"
                                data-src-retina="assets/img/zipzap2x.jpg" width="120" height="60" /></a>
                    </div>
                    <div class="navbar-collapse collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="index2.php">Home</a></li>
                            <li><a href="konfirmasipembayaran1.php">Konfirmasi Pembayaran</a></li>                            
                            <li><a href="contact2.php">About Us</a></li>
                            <li><a href="logout.php">Logout</a></li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>

</head>
<!-- END HEAD -->
<body >
    <div class="container" style="padding-top: 110px" style="padding-bottom: 20px">
        
    <form method="post" action="">
        <div class="container" align="center">
            <h3 align="center">Masukkan Jumlah Sepatu yang ingin Anda Cuci (Min : 4)</h3>
            <input align="middle" type="number" placeholder="Jumlah Sepatu" min="4" name="jumlah" required style="width:40%;" >
        </div>
        &nbsp;
        <div class="container" align="center">
                <!-- <input type="button" value="Submit" name="submit"> -->
                <!-- <button type "submit" name = "submit" class = "btn btn-info">Submit</a> -->
                <button type="submit" name="submits">Submit</button>
            <!-- <button class="btn success" type "submit" name = "submit" class = "btn btn-info">Submit</a> -->
        </div>
        <p>&nbsp;</p>
        
    </form>
    </div>

    <!-- BEGIN CORE JS FRAMEWORK -->
    <script type="text/javascript" src="assets/plugins/jquery-1.8.3.min.js"></script>
    <script src="assets/plugins/boostrapv3/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- END CORE JS FRAMEWORK -->
    <!-- BEGIN JS PLUGIN -->
    <script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
    <script src="assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="assets/plugins/jquery-nicescroll/jquery.nicescroll.min.js"></script>
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script src="assets/plugins/jquery-gmap/gmaps.js" type="text/javascript"></script>
    <!-- END JS PLUGIN -->
    <script src="assets/js/google_maps.js" type="text/javascript"></script>
    <script type="text/javascript" src="assets/js/core.js"></script>
  
</body>
<footer>
    <div class="section white footer page-footer">
            <div class="container">
                <div class="p-t-30 p-b-50">
                    <div class="row">
                        <div class="col-md-2 col-lg-2 col-sm-2 col-xs-12 xs-m-b-20">                            
                            <br />
                            © ZipZap Shoe Laundry.
                            <br />
                            All Rights Reserved.
                        </div>
                        <div class="col-md-4 col-lg-3 col-sm-4  col-xs-12 xs-m-b-20">
                            <address class="xs-no-padding  col-md-6 col-lg-6 col-sm-6  col-xs-12">
                                Jl. Lebak Bulus 1 No.12,<br>
                                Jakarta Selatan,<br>
                                Indonesia 12430.
                            </address>
                            <div class="xs-no-padding col-md-6 col-lg-6 col-sm-6">
                                <div>
                                    +62 813-1458-4964<br> +62 878-8361-9733</div>
                                <a href="javascript:">id.zipzap@gmail.com</a>
                            </div>
                            <div class="clearfix">
                            </div>
                        </div>                        
                        <div class="col-md-2 col-lg-2 col-sm-2  col-xs-12 ">
                            <div class="bold">
                                FOLLOW US</div>
                            <br />
                            <a href="https://www.instagram.com/id.zipzap"><i class="fa fa-instagram fa-2x"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</footer>
</html>