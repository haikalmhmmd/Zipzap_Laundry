<!DOCTYPE html>

<?php
    session_start();

    if(! isset($_SESSION['username']))
    {
        header("location: indexx.php");
    }

    $email = $_SESSION['email'];

    //koneksi ke database
    include ('config.php');

?>

<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="utf-8" />
    <title>ZipZap Shoe Laundry</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta content="" name="description" />
    <meta content="" name="author" />
    <!-- BEGIN CORE CSS FRAMEWORK -->
    <link rel="stylesheet" type="text/css" href="assets/plugins/owl-carousel/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="assets/plugins/owl-carousel/owl.theme.css" />
    <link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css"
        media="screen" />
    <link href="assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet"
        type="text/css" />
    <link href="assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet"
        type="text/css" />
    <!-- END CORE CSS FRAMEWORK -->
    <!-- BEGIN CSS TEMPLATE -->
    <link href="assets/css/style.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/animate.min.css" rel="stylesheet" type="text/css" />
    <!-- END CSS TEMPLATE -->
    <script type="text/javascript" src="assets/plugins/jquery-1.8.3.min.js"></script>
</head>
<!-- END HEAD -->
<body >
    <div class="main-wrapper">
        <div role="navigation" class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="compressed">
                    <div class="navbar-header">
                        <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle"
                            type="button">
                            <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span><span
                                class="icon-bar"></span><span class="icon-bar"></span>
                        </button>
                        <a href="#" class="navbar-brand compressed">
                            <img src="assets/img/zipzap.jpg" alt="" data-src="assets/img/zipzap.jpg"
                                width="120" height="60" /></a>
                    </div>
                    <div class="navbar-collapse collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="index2.php">Home</a></li>                            
                            <li><a href="order.html">Order</a></li>                            
                            <li><a href="contact2.html">About Us</a></li>
                            <li><a href="logout.php">Logout</a></li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>

        <div class="container" style="padding-top: 150px" style="padding-bottom: 20px">
            <div class="row profile">
                <div class="col-md-3">
                    <div class="profile-sidebar">
                        <?php
                            $query = "SELECT * FROM user WHERE email = '$email'";
                            $result = mysqli_query($koneksi,$query) or die(mysqli_error());
                            while( $row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                        ?>

                        <div class="profile-userpic">
                            <?php 
                                echo '<img src="data:image/jpeg;base64,'.base64_encode( $row['foto_user'] ).'" alt="Avatar" align="center"/>';
                            ?>
                        </div>
                        &nbsp;
                        <div class="profile-usermenu">
                            <div class="profile-usertitle-name">
                                <table class="table table-striped"style=" width:80%">  
                                  <tr>
                                    <th><i class="glyphicon glyphicon-user"></i>  Nama Lengkap</th>
                                    <td><?php echo $row['nama_lengkap']; ?></td>
                                  </tr>
                                  <tr>
                                    <th><i class="glyphicon glyphicon-user"></i>  Jenis Kelamin</th>
                                    <td><?php echo $row['jenis_kelamin']; ?></td>
                                  </tr>
                                  <tr>
                                      <th><i class="glyphicon glyphicon-user"></i>  Username</th>
                                      <td><?php echo $row['username']; ?></td> 
                                  </tr>
                                  <tr>
                                      <th><i class="glyphicon glyphicon-envelope"></i>  Email</th>
                                      <td><?php echo $row['email']; ?></td>
                                  </tr>
                                  <tr>
                                      <th><i class="glyphicon glyphicon-phone-alt"></i>  No. Telepon</th>
                                      <td><?php echo $row['no_tlp']; ?></td>
                                  </tr>             

                                <?php } ?>
                                </table> 
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <h3>History Pesanan</h3>
                    <div class="container" style="padding-bottom: 20px">
                        <table class="table table-bordered table-striped"style=" width:80%">
                          <tr>
                            <th width="10">ID Pesanan</th>
                            <th width="60">Tanggal Pesanan</th>
                            <th width="60">Total Harga</th>
                            <th width="60">Status</th>
                            <th width="60">Alamat</th>
                          </tr> 
                            <?php
                                $query = "SELECT * FROM pesanan, detail_pesanan WHERE email = '$email' AND pesanan.id_pesanan = detail_pesanan.id_pesanan";
                                $result = mysqli_query($koneksi,$query) or die(mysqli_error());
                                while( $row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                            ?>                    
                          <tr>
                            <td><?php echo "#";echo $row['id_pesanan']; ?></td>
                            <td><?php echo $row['tgl_pesanan']; ?></td> 
                            <td><?php echo $row['total_harga']; ?></td>
                            <td><?php echo $row['status']; ?></td>
                            <td><?php echo $row['alamat']; ?></td>
                        </tr>
                        <?php } ?>
                        </table> 
                    </div>
                    
                </div>
            </div>
        </div>
        

        <div class="section white footer" style="margin-top: 30px">
            <div class="container">
                <div class="p-t-30 p-b-50">
                    <div class="row">
                        <div class="col-md-2 col-lg-2 col-sm-2 col-xs-12 xs-m-b-20">
                            © ZipZap Shoe Laundry.
                            <br />
                            All Rights Reserved.
                        </div>
                        <div class="col-md-4 col-lg-3 col-sm-4  col-xs-12 xs-m-b-20">
                            <address class="xs-no-padding  col-md-6 col-lg-6 col-sm-6  col-xs-12">
                                Jl. Lebak Bulus 1 No.12,<br>
                                Jakarta Selatan,<br>
                                Indonesia 12430.
                            </address>
                            <div class="xs-no-padding col-md-6 col-lg-6 col-sm-6">
                                <div>
                                    +62 813-1458-4964<br> +62 878-8361-9733</div>
                                    <a href="javascript:">id.zipzap@gmail.com</a>                                
                            </div>
                            <div class="clearfix">
                            </div>
                        </div>
                        <div class="col-md-2 col-lg-2 col-sm-2  col-xs-12 ">
                            <div class="bold">
                                FOLLOW US</div>
                            <br/>
                            <a href="https://www.instagram.com/id.zipzap"><i class="fa fa-instagram fa-2x"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- BEGIN CORE JS FRAMEWORK -->
    <script type="text/javascript" src="assets/plugins/jquery-1.8.3.min.js"></script>
    <script src="assets/plugins/boostrapv3/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- END CORE JS FRAMEWORK -->
    <!-- BEGIN JS PLUGIN -->
    <script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
    <script src="assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="assets/plugins/jquery-nicescroll/jquery.nicescroll.min.js"></script>
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script src="assets/plugins/jquery-gmap/gmaps.js" type="text/javascript"></script>
    <!-- END JS PLUGIN -->
    <script src="assets/js/google_maps.js" type="text/javascript"></script>
    <script type="text/javascript" src="assets/js/core.js"></script>
  
</body>
</html>