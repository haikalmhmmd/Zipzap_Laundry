<?php
    if (isset($_POST['submit_row'])) 
    {
        $connect = mysqli_connect ("localhost", "root", "", "sample");

        $name=$_POST['name'];
        $job=$_POST['job'];
        $age=$_POST['age'];

        for ($i=0; $i < count($name); $i++)
        { 
            if($name[$i]!="" && $age[$i]!="" && $job[$i]!="")
            {
                $mysqli = "INSERT into employee_table(name,age,job) values ('$name[$i]','$age[$i]','$job[$i]')";
                mysqli_query($connect,$mysqli);
            }
        }
    }
?>