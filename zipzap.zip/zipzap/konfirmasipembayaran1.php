<!DOCTYPE html>
<?php
    session_start();

    if(! isset($_SESSION['username']))
    {
        header("location: indexx.php");
    }

    //koneksi ke database
    include ('config.php');

    $pesanan = $_SESSION['konfirmasi'];

     if(isset($_POST['submit']))
    {
        $id_pesanan  = $_POST['id_pesanan'];
        $nama   = $_POST['nama'];
        $norek   = $_POST['norek'];
        $foto  = $_POST['foto'];
        $mysqli  = "INSERT INTO konfirmasi (id_pesanan,nama,norek,foto) VALUES ( '$id_pesanan', '$nama' , '$norek' , '$foto' )";
        $result  = mysqli_query($koneksi, $mysqli);
        if ($result) {
            echo '<script LANGUAGE="JavaScript">
            alert("Berhasil")
            window.location.href="index2.php?page=order";
            </script>';
        } else {
            echo '<script LANGUAGE="JavaScript">
            alert("gagal");
            </script>';}
        mysqli_close($koneksi);        
    }
?>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="utf-8" />
    <title>ZipZap Shoe Laundry</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta content="" name="description" />
    <meta content="" name="author" />
    <!-- BEGIN CORE CSS FRAMEWORK -->
    <link rel="stylesheet" type="text/css" href="assets/plugins/owl-carousel/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="assets/plugins/owl-carousel/owl.theme.css" />
    <link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css"
        media="screen" />
    <link href="assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet"
        type="text/css" />
    <link href="assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet"
        type="text/css" />
    <!-- END CORE CSS FRAMEWORK -->
    <!-- BEGIN CSS TEMPLATE -->
    <link href="assets/css/style.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/animate.min.css" rel="stylesheet" type="text/css" />
    <!-- END CSS TEMPLATE -->
    <script type="text/javascript" src="assets/plugins/jquery-1.8.3.min.js"></script>
</head>
<!-- END HEAD -->
<body >
    <div class="main-wrapper">
        <div role="navigation" class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="compressed">
                    <div class="navbar-header">
                        <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle"
                            type="button">
                            <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span><span
                                class="icon-bar"></span><span class="icon-bar"></span>
                        </button>
                        <a href="#" class="navbar-brand compressed">
                            <img src="assets/img/zipzap.jpg" alt="" data-src="assets/img/zipzap.jpg"
                                data-src-retina="assets/img/logo2x.png" width="119" height="50" /></a>
                    </div>
                    <div class="navbar-collapse collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="index2.php">Home</a></li>                                                             
                                <li><a href="order.php">Order</a></li>
                                <li><a href="contact2.html">About Us</a></li>
                                <li><a href="logout.php">Logout</a></li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>
        <div class="section grey text-center m-t-60 p-t-40 p-b-40" id="banner-footer">
        <div class="container" style="padding-top: 100px" style="padding-bottom: 20px">
        <h1>Konfirmasi Pembayaran</h1>
        <div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
            <div class="login-panel panel panel-default">
                <div class="panel-body">
                    <div style="color: red;margin-bottom: 15px;">
                    <?php
                    // Cek apakah terdapat cookie dengan nama message
                    if(isset($_COOKIE["message"])){ // Jika ada
                    echo $_COOKIE["message"]; // Tampilkan pesannya
                    }
                    ?>
                    </div>
                    <form method="post">
                            <?php
                            $query = "SELECT * FROM pesanan WHERE id_pesanan=$pesanan";
                            $result = mysqli_query($koneksi,$query) or die(mysqli_error());
                            ?>
                            <fieldset>

                            <div class="form-group">
                                <label>Order ID</label> <br>
                            <?php while( $row = mysqli_fetch_array($result, MYSQLI_ASSOC)) { ?>
                            <h4><?php echo $row['id_pesanan']?></h4>
                            <input type="hidden" name="id_pesanan" value="<?php echo $row['id_pesanan']; ?>">
                            <?php } ?> 
                            &nbsp;

                            </div>   
                            <div class="form-group">
                                <label>Masukan nama pemilik rekening</label> <br>
                                <input type="text" name="nama">
                            </div>
                            <div class="form-group">
                                <label>Masukan nomor rekening</label> <br>
                                <input type="text" name="norek">
                            </div>
                            <div class="form-group">
                            <div class="form-group">
                                <input type="file" class="form-control" name="foto">
                            </div>
                            </div>
                            <div class="row">
                            <div class="col-xs-12">
                            <button class="btn btn-success btn-lg btn-block" name="submit" type="submit">Konfirmasi Pembayaran</button>
                            </div>
                            </div>
                            </fieldset>
                    </form>
                </div>
            </div>
        </div><!-- /.col-->
    </div>
    </div>
        
    </div>
    <!-- BEGIN CORE JS FRAMEWORK -->
    <script type="text/javascript" src="assets/plugins/jquery-1.8.3.min.js"></script>
    <script src="assets/plugins/boostrapv3/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- END CORE JS FRAMEWORK -->
    <!-- BEGIN JS PLUGIN -->
    <script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
    <script src="assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="assets/plugins/jquery-nicescroll/jquery.nicescroll.min.js"></script>
    <!-- END JS PLUGIN -->
</body>
<footer>
    <div class="section white footer page-footer">
            <div class="container">
                <div class="p-t-30 p-b-50">
                    <div class="row">
                        <div class="col-md-2 col-lg-2 col-sm-2 col-xs-12 xs-m-b-20">                            
                            <br />
                            © ZipZap Shoe Laundry.
                            <br />
                            All Rights Reserved.
                        </div>
                        <div class="col-md-4 col-lg-3 col-sm-4  col-xs-12 xs-m-b-20">
                            <address class="xs-no-padding  col-md-6 col-lg-6 col-sm-6  col-xs-12">
                                Jl. Lebak Bulus 1 No.12,<br>
                                Jakarta Selatan,<br>
                                Indonesia 12430.
                            </address>
                            <div class="xs-no-padding col-md-6 col-lg-6 col-sm-6">
                                <div>
                                    +62 813-1458-4964<br> +62 878-8361-9733</div>
                                <a href="javascript:">id.zipzap@gmail.com</a>
                            </div>
                            <div class="clearfix">
                            </div>
                        </div>                        
                        <div class="col-md-2 col-lg-2 col-sm-2  col-xs-12 ">
                            <div class="bold">
                                FOLLOW US</div>
                            <br />
                            <a href="https://www.instagram.com/id.zipzap"><i class="fa fa-instagram fa-2x"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</footer>
</html>