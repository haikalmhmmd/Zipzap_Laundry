<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Add Remove Dynamic HTML Fields using JQuery Plugin in PHP</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
        <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
        <script src="repeater.js" type="text/javascript"></script>
    </head>
<body>
    <div class="container">
        <br />
        <h3 align="center">Add Remove Dynamic HTML Fields using JQuery Plugin in PHP</h3>
        <br />
        <div style="width:100%; max-width: 600px; margin:0 auto;">
            <div class="panel panel-default">
                <div class="panel-heading">Add Programming Skill Details</div>
                <div class="panel-body">
                    <span id="success_result"></span>
                    <form method="post" id="repeater_form">
                        <div class="form-group">
                            <label>Enter Programmer Name</label>
                            <input type="text" name="name" id="name" class="form-control" required />
                        </div>
                        <div id="repeater">
                            <div class="repeater-heading" align="right">
                                <button type="button" class="btn btn-primary repeater-add-btn">Add More Skill</button>
                            </div>
                            <div class="clearfix"></div>
                            <div class="items" data-group="programming_languages">
                                <div class="item-content">
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-md-9">
                                                <label>Select Programming Skill</label>
                                                <select data-skip-name="true" data-name="skill[]" class="form-control">
                                                    <option value="">Select</option>
                                                    <option value="PHP">PHP</option>
                                                    <option value="Mysql">Mysql</option>
                                                    <option value="JQuery">JQuery</option>
                                                    <option value="Ajax">Ajax</option>
                                                    <option value="AngularJS">AngularJS</option>
                                                    <option value="Codeigniter">Codeigniter</option>
                                                    <option value="Laravel">Laravel</option>
                                                    <option value="Bootstrap">Bootstrap</option>
                                                </select>
                                            </div>
                                            <div class="col-md-3" style="margin-top:24px;" align="center">
                                                <button id="remove-btn" onclick="$(this).parents('.items').remove()" class="btn btn-danger">Remove</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="form-group" align="center">
                            <br /><br />
                            <input type="submit" name="insert" class="btn btn-success" value="insert" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    $(document).ready(function(){

        $('#repeater').createRepeater();

        $('#repeater_form').on('submit', function(event){
            event.preventDefault();
            $.ajax({
                url:"insert.php",
                method:"POST",
                data:$(this).serialize(),
                success:function(data)
                {
                    $('#repeater_form')[0].reset();
                    $('#repeater').createRepeater();
                    $('#success_result').html(data);
                }
            })
        });

    });
        
    </script>
    </body>
</html>


<!DOCTYPE html>

<?php
    include("config.php");

    $query = "SELECT * FROM metode_cuci ";
    $result = mysqli_query($koneksi,$query) or die(mysqli_error());
?>

<html>
<head>

    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="utf-8" />
    <title>ZipZap Shoe Laundry</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta content="" name="description" />
    <meta content="" name="author" />
    <link rel="stylesheet" type="text/css" href="assets/plugins/owl-carousel/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="assets/plugins/owl-carousel/owl.theme.css" />
    <link rel="stylesheet" type="text/css" href="assets/plugins/headereffects/css/component.css">
    <link rel="stylesheet" type="text/css" href="assets/plugins/headereffects/css/normalize.css" />
    <link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css"
        media="screen" />
    <!-- BEGIN CORE CSS FRAMEWORK -->
    <link href="assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet"
        type="text/css" />
    <link href="assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet"
        type="text/css" />
    <!-- END CORE CSS FRAMEWORK -->
    <!-- BEGIN CSS TEMPLATE -->
    <link href="assets/css/style.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/magic_space.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/animate.min.css" rel="stylesheet" type="text/css" />
    <!-- END CSS TEMPLATE -->
    <script type="text/javascript" src="assets/plugins/jquery-1.8.3.min.js"></script>
    <!-- SLIDER REVOLUTION 4.x SCRIPTS  -->
    <script type="text/javascript" src="assets/plugins/slider-plugin/js/slider1.min.js"></script>
    <script type="text/javascript" src="assets/plugins/slider-plugin/js/slider2.min.js"></script>
    <link rel="stylesheet" type="text/css" href="assets/plugins/slider-plugin/css/settings.css"
        media="screen" />
    <script type="text/javascript" src="jquery.js"></script>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Add Remove Dynamic HTML Fields using JQuery Plugin in PHP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <script src="repeater.js" type="text/javascript"></script>
    <script type="text/javascript">
        function add_row()
        {
            $rowno = $("#employee_table tr").length;
            $rowno = $rowno+1;
            $("#employee_table tr:last").after("<tr id='row"+$rowno+"'><td><div class='container' style='padding-top: 110px' style='padding-bottom: 20px'><h3>Pilh Jenis Sepatu Anda</h3><div class='col-md-6'><div class='card' align='center' style='height: 250px'><img src='assets/img/testimonial_img1.png' alt='Avatar' style='width:25%; margin-top: 20px' align='center'><div class='container2'><h4><b>Casual</b></h4><input type='radio' name='product' value='casual' align='center'/></div></div></div></div><div class='container' style='padding-top: 110px' style='padding-bottom: 20px'><h3>Pilh Jenis Sepatu Anda</h3><div class='col-md-6'><div class='card' align='center' style='height: 250px'><img src='assets/img/testimonial_img1.png' alt='Avatar' style='width:25%; margin-top: 20px' align='center'><div class='container2'><h4><b>Casual</b></h4><input type='radio' name='product' value='casual' align='center'/></div></div></div></div></td></td></tr>")
        }

        function delete_row(rowno,rowno1)
        {
            $('#'+rowno).remove();
            $('#'+rowno1).remove();
        }
        
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

</head>

<body>
    <div id="wrapper">
        
        <div id="form_div">
            <form method="post" id="form_divs" action="store_detail.php">
                <table id="employee_table" align="center">
                    <tr id="row1">
                        <td><input type="text" name="name[]" placeholder="Enter Name"></td>
                        <td><input type="text" name="age[]" placeholder="Enter Age"></td>
                        <td><input type="text" name="job[]" placeholder="Enter Job"></td>
                        <div class="container" style="padding-top: 110px" style="padding-bottom: 20px">
                        <h3>Pilh Jenis Sepatu Anda</h3>
                        <div class="col-md-6">
                            <div class="card" align="center" style="height: 250px">            
                                <img src="assets/img/testimonial_img1.png" alt="Avatar" style="width:25%; margin-top: 20px" align="center">
                                <div class="container2">
                                    <h4><b>Casual</b></h4>
                                    <input type="radio" name="product" value="casual" align="center"/>
                                </div>
                            </div> 
                        </div>
                        <div class="col-md-6">
                            <div class="card" align="center" style="height: 250px"> 
                                <img src="assets/img/testimonial_img1.png" alt="Avatar" style="width:25%; margin-top: 20px" align="center">
                                <div class="container2">
                                    <h4><b>Leather</b></h4>
                                    <input type="radio" name="product" value="leather" align="center"/>
                                </div>
                            </div> 
                        </div>
                        <p>&nbsp;</p>

                        <h3>Pilh Treatment yang Anda inginkan</h3>
                        <?php while( $row = mysqli_fetch_array($result, MYSQLI_ASSOC) ) : ?>
                        <div class="col-md-4">
                            <div class="card" align="center">
                                <?php echo '<img src="data:image/jpeg;base64,'.base64_encode( $row['foto'] ).'" alt="Avatar" style="width:90%; margin-top: 20px" align="center"/>';?>
                                <div class="container2">
                                    <h4><b><?php echo $row['jenis_treatment']; echo " Treatment" ; ?></b></h4>
                                    <p><?php echo $row['deskripsi']; ?></p>
                                    <input type="radio" name="treatment" align="center" value="<?php echo $row['jenis_treatment'];?>" />               
                                </div>
                            </div> 
                        </div>
                       
                        <?php endwhile;?>

                        <div class="col-md-12">
                            <h3>Deskripsi</h3>
                            <input type="text" placeholder="Deskripsi" name="desc" required style="width:100%">
                        </div>
                        <p>&nbsp;</p>
                        <div class="col-md-12">
                            <h3>Masukkan foto sepatu Anda</h3>
                            <input type="file" name="foto" style="width:100%" multiple>
                        </div>
                        <p>&nbsp;</p>
                        <div class="container" align="center">
                                <!-- <input type="button" value="Submit" name="submit"> -->
                                <!-- <button type "submit" name = "submit" class = "btn btn-info">Submit</a> -->
                                <button type="submit" name="submits">Submit</button>
                            <!-- <button class="btn success" type "submit" name = "submit" class = "btn btn-info">Submit</a> -->
                        </div>
                        <p>&nbsp;</p>
                        </div>
                    </tr>
                </table>
                <input type="button" onclick="add_row();" value="ADD ROW">
                <input type="submit" name="submit_row" value="SUBMIT">
                
            </form>
        </div>
    </div>
</body>
</html>
