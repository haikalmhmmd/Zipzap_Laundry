<?php include 'theme_admin/header.php'; ?>

     
      <!-- Left side column. contains the logo and sidebar -->
       <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
                    <!-- sidebar menu: : style can be found in sidebar.less -->
           <ul class="sidebar-menu">
            <li class="header" align="center">ADMIN</li>
            <li class="active">
                <a href="<?php $_SERVER[SCRIPT_NAME];?>index_admin.php">  
                 <i class="fa fa-home"></i> <span>Beranda</span>
              </a>
            </li>
            
            <li class="active">
              <a href="<?php $_SERVER[SCRIPT_NAME];?>?page=order">
                <i class="fa fa-cart-arrow-down"></i> <span>Order</span>  
              </a>
            </li>

            <li class="active">
              <a href="<?php $_SERVER[SCRIPT_NAME];?>?page=treatment">
                <i class="fa fa-check-square"></i> <span>Jenis Treatment</span>  
              </a>
            </li>

            <li class="active">
              <a href="<?php $_SERVER[SCRIPT_NAME];?>?page=sepatu">
                <i class="fa fa-check-square-o"></i> <span>Jenis Sepatu</span>  
              </a>
            </li>  
            
            <li class="active">
              <a href="<?php $_SERVER[SCRIPT_NAME];?>?page=user">
                <i class="fa fa-user"></i> <span>User</span>  
              </a>
            </li>
            
            <li class="active">
              <a href="<?php $_SERVER[SCRIPT_NAME];?>?page=logout">
                <i class="fa fa-user"></i> <span>logout</span>  
              </a>
            </li>            
          </ul>
        </section>
     
        <!-- /.sidebar -->
      </aside>
      
       <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>Detail Pesanan</h1>
          <ol class="breadcrumb">
            <li><a href="index_admin.php"><i class="fa fa-dashboard"></i> Beranda</a></li>
            <li><a href="#">Detail Pesanan</a></li>
            
          </ol>
        </section>
        <!-- Main content -->
        <section class="content">
             
            <!--edit-->
            <?php
                        $id=$_GET['id_detail'];
                        $sql="SELECT  * FROM detail_pesanan where id_detail='$id' ";
                        
                        if (!$result=  mysqli_query($koneksi, $sql)){
                        die('Error:'.mysqli_error($koneksi));
                        }  else {
                        if (mysqli_num_rows($result)> 0){
                        while ($row=  mysqli_fetch_assoc($result)){
                    ?>
           
                   <?php                
                        }
                    }  else {
                    echo '';    
                    }
                    }?> 
          <!-- Default box -->
          <div class="box">
            <div class="box-body">
                  <table id="example1" class="table table-striped dataTable no-footer">
                    <thead>
                      <tr> 
                         <th>No</th>
                        <th>Id Pesanan</th>
                        <th>Jenis Treatment</th>
                        <th>Deskripsi</th>
                        <th>Foto Detail</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php
                         $sql="SELECT  * 
                              FROM user, pesanan, metode_pembayaran, metode_pengiriman,detail_pesanan, metode_cuci
                              WHERE user.email = pesanan.email
                              and pesanan.id_metode_pembayaran = metode_pembayaran.id_metode_pembayaran
                              and pesanan.id_pesanan = detail_pesanan.id_pesanan
                              and detail_pesanan.id_metode_cuci = metode_cuci.id_metode_cuci
                              ";
                        $no=1;
                        if (!$result=  mysqli_query($koneksi, $sql)){
                        die('Error:'.mysqli_error($koneksi));
                        }  else {
                        if (mysqli_num_rows($result)> 0){
                        while ($row=  mysqli_fetch_assoc($result)){
                    ?>
                    
                          <tr>
                            <td><?php echo $no ;?></td>
                            <td><?php echo $row['id_pesanan'];?></td>
                            <td><?php echo $row['jenis_treatment'];?></td>
                            <td><?php echo $row['deskripsi_detail'];?></td>
                            <td><?php 
                            echo '<img src="data:image/jpeg;base64,'.base64_encode( $row['foto_detail'] ).'" alt="Not found" style="width:90%" align="center"/>';
                        ?></td>
                        </tr>    
                            <?php    
                    $no++;                    
                        }
                    }  else {
                    echo '';    
                    }
                    }?>
                    </tbody>
                   
                     
                  </table>
            </div><!-- /.box-body -->
             
          </div><!-- /.box --> 
        </section><!-- /.content -->
      </div><!-- /.content-wrapper --> 
    </div>
   
  </div>
</div>
</div>
</form>

      <!-- Content Wrapper. Contains page content -->
      
     
<?php include 'theme_admin/footer.php'; ?>