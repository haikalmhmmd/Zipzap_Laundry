<!DOCTYPE html>

<?php
    session_start();

    if(! isset($_SESSION['username']))
    {
        header("location: index.html");
    }

    //koneksi ke database
    include ('config.php');

    $email = $_SESSION['email'];
    $products = $_SESSION['products'];
    $treatments = $_SESSION['treatments'];
    $fotos = $_SESSION['jumlah'];
    $desc = $_SESSION['desc'];
    $jumlah = $_SESSION['jumlah'];

     if(isset($_POST['submits']))
    {
        date_default_timezone_set('Asia/Jakarta'); 
        $id = rand(0,10000);
        $tanggal = date('Y-m-d');
        $tanggals = date('dmY');
        $kode = "$tanggals$id";
        $waktu = date('H:i:s');

        $alamat = $_POST['alamat'];
        $pembayaran = $_POST['metode_pembayaran'];
        $pengiriman = $_POST["metode_pengiriman"];
        $harga = $_POST['harga'];

        $_SESSION['harga'] = $harga;
        $_SESSION['pembayaran'] =  $pembayaran;
        // // $desc = $_POST['desc'];

        // var_dump($products);
        // var_dump($treatments);
        // var_dump($desc);
        // var_dump($kode);

        // $id = rand(0,10000);
        // $tanggal = date('Y-m-d');
        // $tanggals = date('dmY');
        // $kode = "$tanggals$id";

        // $_SESSION['products'] = $products;
        // $_SESSION['treatments'] = $treatments;
        // $_SESSION['fotos'] = $fotos;
        // $_SESSION['desc'] =  $desc;
        // $_SESSION['id'] = $id;
        // $_SESSION['tanggal'] = $tanggal;
        // $_SESSION['tanggals'] = $tanggals;
        // $_SESSION['kode'] = $kode;

        $query = "INSERT INTO pesanan VALUES ('$kode', '$tanggal', '$waktu', '$harga', '$email', 'Failed', '$alamat', '$pembayaran', '$pengiriman')";
        mysqli_query($koneksi, $query);

        for ($i=0; $i < $jumlah ; $i++)
        { 
          $query2 = "INSERT INTO detail_pesanan (id_pesanan, id_metode_cuci, deskripsi, foto_detail) VALUES ('$kode', '$treatments[$i]', '$desc[$i]', '$fotos[$i]')";
          mysqli_query($koneksi, $query2);
        }

        header("location: notes.php");
    }
?>

<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="utf-8" />
    <title>ZipZap Shoe Laundry</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta content="" name="description" />
    <meta content="" name="author" />
    <link rel="stylesheet" type="text/css" href="assets/plugins/owl-carousel/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="assets/plugins/owl-carousel/owl.theme.css" />
    <link rel="stylesheet" type="text/css" href="assets/plugins/headereffects/css/component.css">
    <link rel="stylesheet" type="text/css" href="assets/plugins/headereffects/css/normalize.css" />
    <link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css"
        media="screen" />
    <!-- BEGIN CORE CSS FRAMEWORK -->
    <link href="assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet"
        type="text/css" />
    <link href="assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet"
        type="text/css" />
    <!-- END CORE CSS FRAMEWORK -->
    <!-- BEGIN CSS TEMPLATE -->
    <link href="assets/css/style.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/magic_space.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/animate.min.css" rel="stylesheet" type="text/css" />
    <!-- END CSS TEMPLATE -->
</head>
<!-- END HEAD -->
<body>
    <div class="main-wrapper">
        <div role="navigation" class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="compressed">
                    <div class="navbar-header">
                        <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle"
                            type="button">
                            <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span><span
                                class="icon-bar"></span><span class="icon-bar"></span>
                        </button>
                        <a href="#" class="navbar-brand compressed">
                            <img src="assets/img/zipzap.jpg" alt="" data-src="assets/img/zipzap.jpg"
                                data-src-retina="assets/img/logo2x.png" width="119" height="50" /></a>
                    </div>
                    <div class="navbar-collapse collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="index2.php">Home</a></li>                                                             
                                <li><a href="order.php">Order</a></li>
                                <li><a href="konfirmasipembayaran1.php">Konfirmasi Pembayaran</a></li>
                                <li><a href="contact2.html">About Us</a></li>
                                <li><a href="logout.php">Logout</a></li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>
	
	
        <!--Main layout-->
  <main class="mt-5 pt-4">
  <br></br>
  <br></br>
  <br></br>
    <div class="container wow fadeIn">
      <h2 class="my-5 h2 text-center">Checkout Form</h2>
      <div class="row">
        <div class="col-md-8 mb-4">
          <form method="post" action="">
            <div class="md-form mb-5">
              <h4>Alamat</h4>
              <input type="text" placeholder="Alamat" name="alamat" required style="width:100%">
            </div>

            &nbsp;

            <div class="md-form mb-5">
              <h4>Metode Pembayaran</h4>
              <select class="custom-select d-block w-100" name='metode_pembayaran' required style="width:100%">
                <?php
                    $query = "SELECT * FROM metode_pembayaran";
                    $result = mysqli_query($koneksi,$query) or die(mysqli_error());
                ?>
                <?php while( $row = mysqli_fetch_array($result, MYSQLI_ASSOC)) { ?>
                <option value="<?php echo $row['id_metode_pembayaran'];?>"><?php echo $row['nama_metode'];?></option>
                <?php } ?>
              </select>
            </div>

            &nbsp;

            <div class="md-form mb-5">
              <h4>Metode Pengiriman</h4>
              <select class="custom-select d-block w-100" name='metode_pengiriman' required style="width:100%">
                <?php
                    $query = "SELECT * FROM metode_pengiriman";
                    $result = mysqli_query($koneksi,$query) or die(mysqli_error());
                ?>
                <?php while( $row = mysqli_fetch_array($result, MYSQLI_ASSOC)) { ?>
                <option value="<?php echo $row['id_metode_pengiriman'];?>"><?php echo $row['nama_metode'];?></option>
                <?php } ?>
              </select>
            </div>
            &nbsp;
            <button class="btn btn-primary btn-lg btn-block" name="submits" type="submit" onclick="return confirm('Konfirmasi Pesanan?');">Submit</button>
        </div>

        <div class="col-md-4 mb-4">

          <!-- Heading -->
          <h4 class="d-flex justify-content-between align-items-center mb-3">
            <span class="text-muted">Keranjang Anda</span> 
          </h4>

          <!-- Cart -->
          <ul class="list-group mb-3 z-depth-1">
            <li class="list-group-item d-flex justify-content-between lh-condensed">
              <div>
                <h6 class="my-0">Jenis Treatment</h6>
                <?php 
                for ($i = 0; $i < $jumlah; $i++)
                { ?>
                  <?php 
                      $query = "SELECT * FROM metode_cuci WHERE status_treatment='active' AND id_metode_cuci = '$treatments[$i]'";
                      $result = mysqli_query($koneksi,$query) or die(mysqli_error()); 
                  ?>
                  <?php while( $row = mysqli_fetch_array($result, MYSQLI_ASSOC) ) { ?>
                    <small class="text-muted"><?php echo $i+1;echo ". "; echo $row['jenis_treatment']; echo " Treatment"; ?></small>
                    <p></p>
                  <?php } ?>
                <?php } ?>
              </div>
            </li>
            <li class="list-group-item d-flex justify-content-between">
              <span>Total Harga</span>
              <?php 
                $harga = 0; 
                for ($i = 0; $i < $jumlah; $i++)
                { ?>
                  <?php 
                      $query = "SELECT * FROM metode_cuci WHERE status_treatment='active' AND id_metode_cuci = '$treatments[$i]'";
                      $result = mysqli_query($koneksi,$query) or die(mysqli_error()); 
                  ?>
                  <?php while( $row = mysqli_fetch_array($result, MYSQLI_ASSOC) ) { ?>
                    <?php
                      $harga = $harga + $row['harga'];
                    ?>
                    <p></p>
                  <?php } ?>
                <?php } ?>
                  <input type="hidden" name="harga" value="<?php echo $harga; ?>">
                </form>
              <strong>Rp. <?php echo $harga;?></strong>
            </li>
          </ul>


        </div>
        <!--Grid column-->

      </div>
      <!--Grid row-->

    </div>
  </main>
  <!--Main layout-->
    <!-- BEGIN CORE JS FRAMEWORK -->
    <script type="text/javascript" src="assets/plugins/jquery-1.8.3.min.js"></script>
    <script src="assets/plugins/boostrapv3/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- END CORE JS FRAMEWORK -->
    <!-- BEGIN JS PLUGIN -->
    <script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
    <script src="assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
    <script src="assets/plugins/modernizr.custom.js" type="text/javascript"></script>
    <script src="assets/plugins/waypoints.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="assets/plugins/jquery-nicescroll/jquery.nicescroll.min.js"></script>
    <script type="text/javascript" src="assets/plugins/jquery-isotope/jquery.isotope.js"></script>
    <!-- END JS PLUGIN -->
    <script type="text/javascript" src="assets/js/core.js"></script>
</body>
<footer>
    <div class="section white footer">
            <div class="container">
                <div class="p-t-30 p-b-50">
                    <div class="row">
                        <div class="col-md-2 col-lg-2 col-sm-2 col-xs-12 xs-m-b-20">                            
                            <br />
                            © ZipZap Shoe Laundry.
                            <br />
                            All Rights Reserved.
                        </div>
                        <div class="col-md-4 col-lg-3 col-sm-4  col-xs-12 xs-m-b-20">
                            <address class="xs-no-padding  col-md-6 col-lg-6 col-sm-6  col-xs-12">
                                Jl. Lebak Bulus 1 No.12,<br>
                                Jakarta Selatan,<br>
                                Indonesia 12430.
                            </address>
                            <div class="xs-no-padding col-md-6 col-lg-6 col-sm-6">
                                <div>
                                    +62 813-1458-4964<br> +62 878-8361-9733</div>
                                <a href="javascript:">id.zipzap@gmail.com</a>
                            </div>
                            <div class="clearfix">
                            </div>
                        </div>                        
                        <div class="col-md-2 col-lg-2 col-sm-2  col-xs-12 ">
                            <div class="bold">
                                FOLLOW US</div>
                            <br />
                            <a href="https://www.instagram.com/id.zipzap"><i class="fa fa-instagram fa-2x"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</footer>
</html>
